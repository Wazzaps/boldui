using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Numerics;

namespace _boldui_protocol {
    static class TraitHelpers {
    }


} // end of namespace _boldui_protocol
